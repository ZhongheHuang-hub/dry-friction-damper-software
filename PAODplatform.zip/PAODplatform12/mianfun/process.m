function out=process(smat,dmat,damper,N)

global  radi 
%% shaft
Mr=smat(1);
Kr=smat(2);
Gr=smat(3);
Cr=smat(4);
Fgr=smat(5);
Me=smat(6);
Krd=smat(7);
Csd=smat(8);

Mr2=smat(11);
Kr2=smat(12);
Gr2=smat(13);
Cr2=smat(14);
Fgr2=smat(15);
Me2=smat(16);
Krd2=smat(17);
Csd2=smat(18);

Osy=smat(21);   
O2sy=smat(22); 


OC1s=smat(23);
OC2s=smat(24);
OC1Cs=smat(25);
OC2Cs=smat(26);
ORs=smat(27);
% OC1cs=smat(27);
% OC2cs=smat(28);
% OC1Ccs=smat(29);
% OC2Ccs=smat(30);


%%
NJ=N+1;
O=zeros(NJ,1); OR=zeros(NJ,1);O2=zeros(NJ,1);
syms r;


for j=1:1:N
    % 轴1
    mr(j)=subs(Mr,r,j);kr(j)=subs(Kr,r,j);
    cr(j)=subs(Cr,r,j);me(j)=subs(Me,r,j);fgr(j)=subs(Fgr,r,j);
    krd(j)=subs(Krd,r,j);csd(j)=subs(Csd,r,j);
    gr(j)=subs(Gr,r,j);
    O(j)=subs(Osy,r,j);
    OR(j)=subs(ORs,r,j);
    
    %轴2
    mr2(j)=subs(Mr2,r,j);kr2(j)=subs(Kr2,r,j);
    cr2(j)=subs(Cr2,r,j);me2(j)=subs(Me2,r,j);fgr2(j)=subs(Fgr2,r,j);
    krd2(j)=subs(Krd2,r,j);csd2(j)=subs(Csd2,r,j);
    gr2(j)=subs(Gr2,r,j);
    O2(j)=subs(O2sy,r,j);
   
    
    OC1(j)=double(subs(OC1s,r,j));
    OC2(j)=double(subs(OC2s,r,j));
    OC1C(j)=double(subs(OC1Cs,r,j));
    OC2C(j)=double(subs(OC2Cs,r,j));
    
%     OC1c(j)=subs(OC1cs,r,j);
%     OC2c(j)=subs(OC2cs,r,j);
%     OC1Cc(j)=subs(OC1Ccs,r,j);
%     OC2Cc(j)=subs( OC2Ccs,r,j);
end

mh=zeros(2*NJ,1);kh=zeros(2*NJ,1);gh=zeros(2*NJ,1);ch=zeros(2*NJ,1);meh=zeros(2*NJ,1);
fh=zeros(2*NJ,1);krdh=zeros(2*NJ,1);csdh=zeros(2*NJ,1);

mh(1:N)=mr(1:N);mh(NJ+1:2*NJ-1)=mr2(1:N);
kh(1:N)=kr(1:N);kh(NJ+1:2*NJ-1)=kr2(1:N);
ch(1:N)=cr(1:N);ch(NJ+1:2*NJ-1)=cr2(1:N);
meh(1:N)=me(1:N);meh(NJ+1:2*NJ-1)=me2(1:N);
krdh(1:N)=krd(1:N);krdh(NJ+1:2*NJ-1)=krd2(1:N);
csdh(1:N)=csd(1:N);csdh(NJ+1:2*NJ-1)=csd2(1:N);
gh(1:N)=gr(1:N);gh(NJ+1:2*NJ-1)=gr2(1:N);


M=diag(mh);
KR=diag(kh);
CR=diag(ch);
KRD=diag(krdh);
CSD=diag(csdh);
GR=diag(gh);
%% 阻尼器

O(NJ)=-1;
OR(NJ)=-1;
O2(NJ)=-1;
ce=dmat.Var2(2);
fn0=dmat.Var2(3);
md=dmat.Var2(5);
Ed=dmat.Var2(6);
u1=dmat.Var2(8);
u2=dmat.Var2(9);
cd=dmat.Var2(11);

ceS=dmat.Var3(2);
fn0S=dmat.Var3(3);
mdS=dmat.Var3(5);
EdS=dmat.Var3(6);
u1S=dmat.Var3(8);
u2S=dmat.Var3(9);
cdS=dmat.Var3(11);


%first
M(NJ,NJ)=md;
CR(NJ,NJ)=cd;

%second
M(2*NJ,2*NJ)=mdS;
CR(2*NJ,2*NJ)=cdS;

fj=2*(u1+u2)*fn0;
fd=fj*0.8;

fj2=2*(u1S+u2S)*fn0S;
fd2=fj2*0.8;


%% connect stiffness
if damper==1
    %有限元的结果
    kc1=0.917e5*1.91;
else
    kc1=0.806e5*2.148;
end

ud=0.4;
Es=1.7e11;%外套的弹性模量
us=0.3;
dd=radi+ce;%接触半径

arf=0.8*(9/16*((1-ud^2)/Ed+(1-us^2)/Es)^2*(1/radi+1/dd))^(1/3);
T0=1/2*mr(1)*0.334^2;
kc2=(1.0948*(md/(md+mr(1))*T0/arf^6))^(1/5); 

Mat=struct('M',M,'KR',KR,'CR',CR,'KRD',KRD,'CSD',CSD,'GR',GR);
Vec=struct('O',O,'OR',OR,'O2',O2,'OC1',OC1,'OC2',OC2,'OC1C',OC1C,'OC2C',OC2C,'meh',meh);
out=struct('Mats',Mat,'Vec',Vec,'kcc',double([kc1,kc2,fj,fd,fj2,fd2]));

end