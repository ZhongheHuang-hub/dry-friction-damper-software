%%��Ħ���� ��608����Ϊ�� m kg 
function dp=bendvfree(t,p)

global rs ;%%���ٶ� rad/s
global  meh  M KR CR  KRD CSD GR O O2 ku kuS ce ceS  qd0 qd0S  kc1 kc2  fj fj2 fd fd2 u3 u4 u5 u3S u4S u5S fn0  fn0S ksp kspS NJ damper  N 
global   OC1 OC2 OC1C OC2C  kpd ks cpr pay paz aaz aay 



s1c=OC1*p(1:N);%1���
s2c=OC2*p(NJ*2+1:NJ*3-1);%2���
sc=s2c-s1c;
s1cc=OC1C*p(1:N);%1�Ƕ� cos 
s2cc=OC2C*p(NJ*2+1:NJ*3-1);%2�Ƕ� cos
scc=s2cc-s1cc;%ע������
sccy=real(scc);%y��Ƕ�
sccz=-imag(scc);%z��Ƕ�


%��ʼƽ��ƫ��
op=(paz+pay*1i)/1e3; 
sc=op+sc*0.15; %��̬�Ӷ�̬
% sc=op;
% sc=sc*0.15;
scz=real(sc);
scy=imag(sc);
bbr=atan2(scz,scy); 

pp1=(cpr^2+abs(sc)^2+2*cpr*abs(sc)*sin(rs*t+bbr))^(1/2)-cpr;
pp2=(cpr^2+abs(sc)^2+2*cpr*abs(sc)*cos(pi/6+rs*t+bbr))^(1/2)-cpr;
pp3=-(cpr^2+abs(sc)^2-2*cpr*abs(sc)*sin(pi/3+rs*t+bbr))^(1/2)+cpr;


uz=pp1*sin(rs*t)+pp2*sin(rs*t+pi*2/3)+pp3*sin(rs*t+pi*4/3);
uy=pp1*cos(rs*t)+pp2*cos(rs*t+pi*2/3)+pp3*cos(rs*t+pi*4/3);

fp=(uz+1i*uy)*kpd;
% fp=0;


az=aaz;ay=aay;%��ʼ��ƫ�� 
amz=az+sccz*0.15; %��̬�Ӷ�̬
amy=ay+sccy*0.15;
% amz=az;
% amy=ay;
% amz=sccz*0.15;
% amy=sccy*0.15;

dz=ks*cpr*(2-2*cos(amz))^(1/2);
apz1=abs(dz*sin(rs*t)*sin(amz));
apz2=abs(dz*sin(rs*t+2/3*pi)*sin(amz));
apz3=abs(dz*sin(rs*t+4/3*pi)*sin(amz));

dy=ks*cpr*(2-2*cos(amy))^(1/2);
apy1=abs(dy*cos(rs*t)*sin(amy));
apy2=abs(dy*cos(rs*t+2/3*pi)*sin(amy));
apy3=abs(dy*cos(rs*t+4/3*pi)*sin(amy));

fay=apz1*sin(rs*t+pi)+apz2*sin(rs*t+pi+2*pi/3)+apz3*sin(rs*t+pi+4*pi/3)+apy1*sin(rs*t+pi)+apy2*sin(rs*t+pi+2*pi/3)+apy3*sin(rs*t+pi+4*pi/3);
faz=apz1*cos(rs*t+pi)+apz2*cos(rs*t+pi+2*pi/3)+apz3*cos(rs*t+pi+4*pi/3)+apy1*cos(rs*t+pi)+apy2*cos(rs*t+pi+2*pi/3)+apy3*cos(rs*t+pi+4*pi/3);
fa=faz+1i*fay;
% fa=0;
%ע�����ķ���
if rs<181
cf1=(fp+fa)*OC1*(rs/180)^2.4;
cf2=(fp+fa)*OC2*(rs/180)^2.4;
else
cf1=(fp+fa)*OC1;
cf2=(fp+fa)*OC2;    
end


cf11=zeros(7,1);
cf12=zeros(7,1);
cf11(1:6)=cf1;
cf12(1:6)=cf2;



%Niʱ�� ����������
ME1=meh(1:NJ)*rs^2;
ME2=meh(NJ+1:NJ*2)*rs^2;

dp=[p(NJ+1:NJ*2);
    M(1:NJ,1:NJ)\(-(KR(1:NJ,1:NJ)-KRD(1:NJ,1:NJ)*rs*1i)*p(1:NJ)-(GR(1:NJ,1:NJ)*rs*1i+CSD(1:NJ,1:NJ)+CR(1:NJ,1:NJ))*p(NJ+1:NJ*2)+ME1*exp(rs*t*1i)+cf11);
    p(NJ*3+1:NJ*4);
   M(NJ+1:NJ*2,NJ+1:NJ*2)\(-(KR(NJ+1:NJ*2,NJ+1:NJ*2)-KRD(NJ+1:NJ*2,NJ+1:NJ*2)*rs*1i)*p(NJ*2+1:NJ*3)-(GR(NJ+1:NJ*2,NJ+1:NJ*2)*rs*1i+CSD(NJ+1:NJ*2,NJ+1:NJ*2)+CR(NJ+1:NJ*2,NJ+1:NJ*2))*p(NJ*3+1:NJ*4)+ME2*exp((rs*t+pi)*1i)-cf12);
  ];

end

