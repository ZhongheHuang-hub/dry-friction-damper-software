%%包含不对中碰摩 m kg 
function dp=bendvc1(t,p)
global rs ;%%角速度 rad/s
global  meh  M KR CR  KRD CSD GR O O2 ku kuS ce ceS  qd0 qd0S  kc1 kc2  fj fj2 fd fd2 u3 u4 u5 u3S u4S u5S fn0  fn0S ksp kspS NJ damper  N 
global   OC1 OC2 OC1C OC2C  kpd ks cpr pay paz aaz aay 

q1=O'*p(1:NJ);
q2=O2'*p(NJ*2+1:NJ*3);
s1c=OC1*p(1:N);%1振幅
s2c=OC2*p(NJ*2+1:NJ*3-1);%2振幅
sc=s2c-s1c;
s1cc=OC1C*p(1:N);%1角度 cos 
s2cc=OC2C*p(NJ*2+1:NJ*3-1);%2角度 cos
scc=s2cc-s1cc;%注意正负
sccy=real(scc);%y向角度
sccz=-imag(scc);%z向角度


%% 平行不对中
%初始平行偏差
op=(paz+pay*1i)/1e3; 
% op=1e-4+2e-4*1i; 

% sc=op+sc*0.15;
sc=op+sc*0.12;

scz=real(sc);
scy=imag(sc);
bbr=atan2(scy,scz); 

pp1=(cpr^2+abs(sc)^2+2*cpr*abs(sc)*cos(bbr-rs*t))^(1/2)-cpr;
pp2=cpr-(cpr^2+abs(sc)^2-2*cpr*abs(sc)*cos(pi/3+bbr-rs*t))^(1/2);
pp3=cpr-(cpr^2+abs(sc)^2-2*cpr*abs(sc)*cos(pi/3+rs*t-bbr))^(1/2);

uy=pp1*sin(rs*t)+pp2*sin(rs*t+pi*2/3)+pp3*sin(rs*t+pi*4/3);
uz=pp1*cos(rs*t)+pp2*cos(rs*t+pi*2/3)+pp3*cos(rs*t+pi*4/3);

fpy=uy*kpd;
fpz=uz*kpd;
fp=fpz+1i*fpy;

%% 角不对中
az=aaz;ay=aay;%初始角偏差 
% az=0.005;ay=0.01;
% amz=az+sccz*0.15;
% amy=ay+sccy*0.15;
amz=az+sccz*0.12;
amy=ay+sccy*0.12;
%  amz=0;
%  amy=0;
dz=ks*cpr*(2-2*cos(amz))^(1/2);
apz1=abs(dz*sin(rs*t)*sin(amz));
apz2=abs(dz*sin(rs*t+2/3*pi)*sin(amz));
apz3=abs(dz*sin(rs*t+4/3*pi)*sin(amz));

dy=ks*cpr*(2-2*cos(amy))^(1/2);
apy1=abs(dy*cos(rs*t)*sin(amy));
apy2=abs(dy*cos(rs*t+2/3*pi)*sin(amy));
apy3=abs(dy*cos(rs*t+4/3*pi)*sin(amy));

fay=apz1*sin(rs*t+pi)+apz2*sin(rs*t+pi+2*pi/3)+apz3*sin(rs*t+pi+4*pi/3)+apy1*sin(rs*t+pi)+apy2*sin(rs*t+pi+2*pi/3)+apy3*sin(rs*t+pi+4*pi/3);
faz=apz1*cos(rs*t+pi)+apz2*cos(rs*t+pi+2*pi/3)+apz3*cos(rs*t+pi+4*pi/3)+apy1*cos(rs*t+pi)+apy2*cos(rs*t+pi+2*pi/3)+apy3*cos(rs*t+pi+4*pi/3);
fa=faz+1i*fay;

%% 力叠加
%注意力的方向
if rs<181
cf1=(fp+fa)*OC1*(rs/180)^2.5;%注意
cf2=(fp+fa)*OC2*(rs/180)^2.5;
else
cf1=(fp+fa)*OC1;%注意
cf2=(fp+fa)*OC2;    
end

cf11=zeros(NJ,1);
cf12=zeros(NJ,1);
cf11(1:N)=cf1;
cf12(1:N)=cf2;

%% 碰摩

E1=abs(q1);%位移 
E2=abs(q2);%位移 
h11=0.5*(sign(abs(E1-ce))+sign(E1-ce));
h12=0.5*(sign(abs(E2-ceS))+sign(E2-ceS));

qz1=real(q1);
qy1=imag(q1);
qz2=real(q2);
qy2=imag(q2);


kc11=kc1;
kc12=kc1;

if damper==1
kct=kc11/1.91;
kcb=kc11/1.91*4.6;
else
kct=kc12/2.148;
kcb=kc12/2.148*5.6;    
end

    if qy1>0 && abs(qz1)<qy1
    kc11=kct;
    end
    if qy1<0 && abs(qz1)<abs(qy1)
    kc11=kcb;
    end
    
    if qy2>0 && abs(qz2)<qy2
    kc12=kct;
    end
    if qy2<0 && abs(qz2)<abs(qy2)
    kc12=kcb;
    end
 
kcf=kc11*kc2/(kc11+kc2);    
kcs=kc12*kc2/(kc12+kc2);%二
fq1=h11*(1+1i*ku)*kcf*q1*(1-ce/E1);
fq2=h12*(1+1i*kuS)*kcs*q2*(1-ceS/E2);

Fq1=fq1*O;%力向量
Fq2=fq2*O2;%力向量

F1(1:NJ)=Fq1(1:NJ);
F1(NJ+1:NJ*2)=Fq2(1:NJ);

qd1=p(NJ);
qd2=p(NJ*3);

qd1m=abs(qd1);
qd2m=abs(qd2);

h21=0.5*(sign(abs(qd1m-qd0))+sign(qd1m-qd0));%判断是到第三阶段
h22=0.5*(sign(abs(qd2m-qd0S))+sign(qd2m-qd0S));%判断是到第三阶段

fh1=abs(fq1);
fh2=abs(fq2);
hf1=0.5*(sign(abs(fh1-fj))+sign(fh1-fj));
hf2=0.5*(sign(abs(fh2-fj2))+sign(fh2-fj2));

if qd1m==0
    qd1m=0.00001;
end

if qd2m==0
    qd2m=0.00001;
end

f2f=hf1*fd*(1-h21)*qd1/qd1m+(1-hf1)*fq1;%f2有时候等于碰摩力 有时候等于摩擦力  1
f2s=hf2*fd2*(1-h22)*qd2/qd2m+(1-hf2)*fq2;%f2有时候等于碰摩力 有时候等于摩擦力  2

dd=3.16e-3;
rm=5.1e-3;

ta1=asin((dd-(qd1m-qd0))/rm);
uA1=sin(ta1)+(cos(ta1)-u3*sin(ta1))*u4+u3*cos(ta1);
uB1=cos(ta1)-u3*sin(ta1)-u3*cos(ta1)*u5-sin(ta1)*u5;
kd1=(fn0+ksp*(qd1m-qd0)*tan(ta1))*uA1/uB1;

ta2=asin((dd-(qd2m-qd0S))/rm);
uA2=sin(ta2)+(cos(ta2)-u3S*sin(ta2))*u4S+u3S*cos(ta2);
uB2=cos(ta2)-u3S*sin(ta2)-u3S*cos(ta2)*u5S-sin(ta2)*u5S;
kd2=(fn0S+kspS*(qd1m-qd0S)*tan(ta1))*uA2/uB2;

% assignin("base","qd0ss",qd0);

f3f=2*h21*kd1*qd1/qd1m;
f3s=2*h22*kd2*qd2/qd2m;

F2f=[0;0;0;0;0;0;f2f;];
F3f=[0;0;0;0;0;0;f3f;];
Ff=Fq1+F2f+F3f;
%%
ME1=meh(1:NJ)*rs^2;
F2s=[0;0;0;0;0;0;f2s;];
F3s=[0;0;0;0;0;0;f3s;];
Fs=Fq2+F2s+F3s;
ME2=meh(NJ+1:NJ*2)*rs^2;

dp=[p(NJ+1:NJ*2);
    M(1:NJ,1:NJ)\(-(KR(1:NJ,1:NJ)-KRD(1:NJ,1:NJ)*rs*1i)*p(1:NJ)-(GR(1:NJ,1:NJ)*rs*1i+CSD(1:NJ,1:NJ)+CR(1:NJ,1:NJ))*p(NJ+1:NJ*2)+ME1*exp(rs*t*1i)-Ff+cf11);
    p(NJ*3+1:NJ*4);
   M(NJ+1:NJ*2,NJ+1:NJ*2)\(-(KR(NJ+1:NJ*2,NJ+1:NJ*2)-KRD(NJ+1:NJ*2,NJ+1:NJ*2)*rs*1i)*p(NJ*2+1:NJ*3)-(GR(NJ+1:NJ*2,NJ+1:NJ*2)*rs*1i+CSD(NJ+1:NJ*2,NJ+1:NJ*2)+CR(NJ+1:NJ*2,NJ+1:NJ*2))*p(NJ*3+1:NJ*4)+ME2*exp((rs*t+pi)*1i)-Fs-cf12);
  ];



