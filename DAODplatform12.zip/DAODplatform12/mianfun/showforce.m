clear ffc
global  qss qdd
ffc=[];
for i=1:101

 ffc(i,:)=fc(qss(i),qdd(i));   
    
end

xli=[0:360/100:360];

plot(xli,ffc(:,1),'linewidth',2);
set(gca,'XTick',[0:60:360]) %改变x轴坐标间隔显示 这里间隔为2
xlim([0,360]);
ylabel('合力 (N)');
xlabel('角度 (°)');
set(gca,'FontSize',18);