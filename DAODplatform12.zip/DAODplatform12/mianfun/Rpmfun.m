function smat= Rpmfun(tsww) % calculate the rpm and other

global  radi 
cc=0.0001;
g=9.8;

Lc1=3.729;
Lc2=-0.076;
% Lc1c=3.670;
% Lc2c=-0.016;

%% shaft 1
cn=728;
kn=1.5e5;
% kn=1.0072e+06*L1-3529300;
L3=76e-3; %双轴一样


den=tsww.Var2(1);
E=tsww.Var2(2);
rad=tsww.Var2(3);
L1=tsww.Var2(4);
radi=tsww.Var2(5);
wi=tsww.Var2(6);
d2=tsww.Var2(7);
thick=tsww.Var2(8);
Ler=tsww.Var2(9);
Rer=tsww.Var2(10);


A=pi*(rad^2-(rad-thick)^2);
I=pi*(rad*2)^4/64*(1-((rad-thick)/rad)^4);
syms x r ;
%内套半径1
rado1=0.138/2;
wo1=50e-3;
tko1=rado1-rad;
Ios1=pi*(rado1*2)^4/64*(1-((rado1-tko1)/rado1)^4)*wo1;

%内套半径2
rado2=0.145/2;
wo2=8e-3;
tko2=rado2-rado1;
Ios2=pi*(rado2*2)^4/64*(1-((rado2-tko2)/rado2)^4)*wo2;
deno=2850;
Io=(Ios1+Ios2)*deno;
tki=radi-rado1;
Iis=pi*(radi*2)^4/64*(1-((radi-tki)/radi)^4)*wi;
deni=7850;
Ii=Iis*deni;
mout=pi*wo1*(rado1^2-(rado1-tko1)^2)*deno+pi*wo2*(rado2^2-(rado2-tko2)^2)*deno+pi*wi*(radi^2-(radi-tki)^2)*deni;

% 积分等

V=sin(pi*r*x/L1);
VD2=diff(V,x,2);
VD4=diff(V,x,4);
V2=V*V;
Mr=den*A*int(V2,x,0,L1)-den*I*int(V*VD2,x,0,L1)+mout*sin(pi*r*d2/L1)-(Ii+Io)*subs(VD2,x,d2);
Kr=E*I*int(V*VD4,x,0,L1)+kn*sin(pi*r*L3/L1);
lj1=eval(sqrt(subs(Kr,r,1)/subs(Mr,r,1)));
lj1rpm=lj1/(2*pi)*60;
Gr=2*den*I*int(V*VD2,x,0,L1)+2*(Ii+Io)*subs(VD2,x,d2);
Cr=cn*sin(pi*r*L3/L1);
Fgr=g*den*A*int(V,x,0,L1);
% Ler=Ler*180*pi/(1000*den*A*L1)/1000/30.6534;
% Rer=Rer*180*pi/(1000*den*A*L1)/1000/30.6534;
% before 2022/1/1
% Ler=Ler/40e4;
% Rer=Rer/40e4;
% uer=(Rer+Ler)/2;
% Me=den*A*int(V2,x,0,L1)*uer;

Me=den*A*int(V2,x,0,L1)*Ler;%me*er 论文中den*a=ms

Krd=cc*Kr;
Csd=cc*Kr;
O=sin(r*pi*d2/L1);
OR=sin(r*pi*1/2);

%% shaft 2

cn2=728;
kn2=0.1e5;

denS=tsww.Var3(1);
ES=tsww.Var3(2);
radS=tsww.Var3(3);
LS=tsww.Var3(4);
radiS=tsww.Var3(5);
wiS=tsww.Var3(6);
d2S=tsww.Var3(7);
thickS=tsww.Var3(8);
LerS=tsww.Var3(9);
RerS=tsww.Var3(10);


AS=pi*(radS^2-(radS-thickS)^2);
IS=pi*(radS*2)^4/64*(1-((radS-thickS)/radS)^4);
syms x r
%内套半径1
rado1S=0.138/2;
wo1S=50e-3;
tko1S=rado1S-radS;
Ios1S=pi*(rado1S*2)^4/64*(1-((rado1S-tko1S)/rado1S)^4)*wo1S;

%内套半径2
rado2S=0.145/2;
wo2S=8e-3;
tko2S=rado2S-rado1S;
Ios2S=pi*(rado2S*2)^4/64*(1-((rado2S-tko2S)/rado2S)^4)*wo2S;
denoS=2850;
IoS=(Ios1S+Ios2S)*denoS;
tkiS=radiS-rado1S;
IisS=pi*(radiS*2)^4/64*(1-((radiS-tkiS)/radiS)^4)*wiS;
deniS=7850;
IiS=IisS*deniS;
moutS=pi*wo1S*(rado1S^2-(rado1S-tko1S)^2)*denoS+pi*wo2S*(rado2S^2-(rado2S-tko2S)^2)*denoS+pi*wiS*(radiS^2-(radiS-tkiS)^2)*deniS;

VSj=sin((pi*r*x)/LS);
VD2S=diff(VSj,x,2);
VD4S=diff(VSj,x,4);
V2S=VSj*VSj;

Mr2=denS*AS*int(V2S,x,0,LS)-denS*IS*int(VSj*VD2S,x,0,LS)+moutS*sin(pi*r*d2S/LS)-(IiS+IoS)*subs(VD2S,x,d2S);%质量
Kr2=ES*IS*int(VSj*VD4S,x,0,LS)+kn2*sin(pi*r*L3/LS);
lj12=eval(sqrt(subs(Kr2,r,1)/subs(Mr2,r,1)));
lj1rpm2=lj12/(2*pi)*60;
Gr2=2*denS*IS*int(VSj*VD2S,x,0,LS)+2*(IiS+IoS)*subs(VD2S,x,d2S);%陀螺 这里面没有 角速度
Cr2=cn2*sin(pi*r*L3/LS);
Fgr2=g*denS*AS*int(V2S,x,0,LS);%%重力

% LerS=LerS/40e4;
% RerS=RerS/40e4;
% uerS=(RerS+LerS)/2;
% Me2=denS*AS*int(V2S,x,0,LS)*uerS;

Me2=denS*AS*int(V2S,x,0,LS)*LerS;



Krd2=cc*Kr2;%
Csd2=cc*Kr2;%
O2=sin(r*pi*d2S/LS);
%% 不对中
OC1=sin(r*pi*Lc1/L1);
OC2=sin(r*pi*Lc2/LS);
OC1C=cos(r*pi*Lc1/L1);
OC2C=cos(r*pi*Lc2/LS);

% OC1c=sin(r*pi*Lc1c/L1);
% OC2c=sin(r*pi*Lc2c/LS);
% OC1Cc=cos(r*pi*Lc1c/L1);
% OC2Cc=cos(r*pi*Lc2c/LS);

%% 输出
smat(1)=Mr;
smat(2)=Kr;
smat(3)=Gr;
smat(4)=Cr;
smat(5)=Fgr;
smat(6)=Me;
smat(7)=Krd;
smat(8)=Csd;
smat(9)=lj1;
smat(10)=lj1rpm;   
smat(11)=Mr2;
smat(12)=Kr2;
smat(13)=Gr2;
smat(14)=Cr2;
smat(15)=Fgr2;
smat(16)=Me2;
smat(17)=Krd2;
smat(18)=Csd2;
smat(19)=lj12;
smat(20)=lj1rpm2;      

smat(21)=O;   
smat(22)=O2;   

smat(23)=OC1;
smat(24)=OC2;
smat(25)=OC1C;
smat(26)=OC2C;
smat(27)=OR;
% smat(27)=OC1c;
% smat(28)=OC2c;
% smat(29)=OC1Cc;
% smat(30)=OC2Cc;


end