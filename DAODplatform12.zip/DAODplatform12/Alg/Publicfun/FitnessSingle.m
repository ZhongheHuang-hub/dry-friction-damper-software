function Fitness = FitnessSingle(Population)


    PopCon   = sum(max(0,Population.cons),2);
    Feasible = PopCon <= 0;
    Fitness  = Feasible.*Population.objs + ~Feasible.*(PopCon+1e10);
end