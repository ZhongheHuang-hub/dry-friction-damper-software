classdef PROBLEM < handle & matlab.mixin.Heterogeneous

    properties
        N        = 100;             	% Population size
        FE       = 0;                   % Number of consumed function evaluations
    end
    properties(SetAccess = protected)
        M;                             	% Number of objectives
        D;                             	% Number of decision variables
        maxFE    = 10000;              	% Maximum number of function evaluations
        encoding = 'real';            	% Encoding scheme of decision variables
        lower    = 0;                 	% Lower bound of decision variables
        upper    = 1;                  	% Upper bound of decision variables
        optimum;                       	% Optimal values of the problem
        PF;                          	% Image of Pareto front
        parameter = {};                	% Other parameters of the problem
%         smat;
        dmato;
        opyfig;
        parsel;
        objsel;
        outt;
    end
    methods(Access = protected)
        function obj = PROBLEM(varargin) %this is 
            isStr = find(cellfun(@ischar,varargin(1:end-1))&~cellfun(@isempty,varargin(2:end))); %the same with algotithm
            for i = isStr(ismember(varargin(isStr),{'N','M','D','maxFE','parameter','lower','upper','outt','dmato','opyfig','parsel','objsel'}))
                obj.(varargin{i}) = varargin{i+1};
            end
            obj.Setting();
            obj.optimum = obj.GetOptimum(10000);
            obj.PF      = obj.GetPF();
        end
    end
    methods
        function Setting(obj)
        %this will be redefined in subclass

        end
        function Population = Initialization(obj,N)
      
            if nargin < 2
            	N = obj.N;
            end
            switch obj.encoding
                case 'binary'
                    PopDec = randi([0,1],N,obj.D);
                case 'permutation'
                    [~,PopDec] = sort(rand(N,obj.D),2);
                otherwise
                    PopDec = unifrnd(repmat(obj.lower,N,1),repmat(obj.upper,N,1));
            end
            Population = SOLUTION(PopDec);
        end
        function PopDec = CalDec(obj,PopDec)
 

            if strcmp(obj.encoding,'real')
                PopDec = max(min(PopDec,repmat(obj.upper,size(PopDec,1),1)),repmat(obj.lower,size(PopDec,1),1));
            end
        end
        function PopObj = CalObj(obj,PopDec)
        % Calculate the objective values of solutions.
    
            PopObj = zeros(size(PopDec,1),obj.M);
        end
        function PopCon = CalCon(obj,PopDec)
        % Calculate the constraint violations of solutions.
     
        
            PopCon = zeros(size(PopDec,1),1);
        end
        function R = GetOptimum(obj,N)
        %Generate the optimums of the problem.
         
            if obj.M > 1
                R = ones(1,obj.M);
            else
                R = 0;
            end
        end
        function R = GetPF(obj)
        %GetPF - Generate the image of Pareto front.
        %
        %   R = obj.GetPF() returns the image of Pareto front for objective
        %   visualization.
        %
        %   For bi-objective optimization problems, the image should be a
        %   one-dimensional curve.
        %
        %   For tri-objective optimization problems, the image should be a
        %   two-dimensional surface.
        %
        %   For constrained multi-objective optimization problems, the
        %   image can be the feasible region.
        %
        %   Example:
        %       R = Problem.GetPF()
        
            R = [];
        end
        function DrawDec(obj,Population)
        %DrawDec - Display a population in the decision space.
        %
        %   obj.DrawDec(P) displays the decision variables of population P.
        %
        %   Example:
        %       Problem.DrawDec(Population)
        
            if strcmp(obj.encoding,'binary')
                Draw(logical(Population.decs));
            else
                Draw(Population.decs,{'\it x\rm_1','\it x\rm_2','\it x\rm_3'});
            end
        end
        function DrawObj(obj,Population)

            ax = Draw(Population.objs,{'\it f\rm_1','\it f\rm_2','\it f\rm_3'});
            if ~isempty(obj.PF)
                if ~iscell(obj.PF)
                    if obj.M == 2

                          ax.XlimMode=auto;ax.YlimMode=auto;  
                        plot(ax,obj.PF(:,1),obj.PF(:,2),'-k','LineWidth',1);
                                              
                    elseif obj.M == 3

                        ax.XlimMode=auto;ax.YlimMode=auto; ax.ZlimMode=auto; 
                        plot3(ax,obj.PF(:,1),obj.PF(:,2),obj.PF(:,3),'-k','LineWidth',1);
                             
                    end
                else
                    if obj.M == 2
                        surf(ax,obj.PF{1},obj.PF{2},obj.PF{3},'EdgeColor','none','FaceColor',[.85 .85 .85]);
                    elseif obj.M == 3
                        surf(ax,obj.PF{1},obj.PF{2},obj.PF{3},'EdgeColor',[.8 .8 .8],'FaceColor','none');
                    end
                    set(ax,'Children',ax.Children(flip(1:end)));
                end
            elseif size(obj.optimum,1) > 1 && obj.M < 4
                if obj.M == 2
                     
                    ax.XlimMode=auto;ax.YlimMode=auto; 
                    plot(ax,obj.optimum(:,1),obj.optimum(:,2),'.k');
                      
                elseif obj.M == 3
                    
                    ax.XlimMode=auto;ax.YlimMode=auto; ax.ZlimMode=auto;
                    plot3(ax,obj.optimum(:,1),obj.optimum(:,2),obj.optimum(:,3),'.k');
                      
                end
            end
        end
    end
    methods(Static, Sealed)
        function obj = Current(obj)
   
            persistent Problem;
            if nargin > 0
                Problem = obj;
            end
            if nargout > 0
                obj = Problem;
            end
        end
    end
	methods(Access = protected, Sealed)
        function varargout = ParameterSet(obj,varargin)

            varargout = varargin;
            specified = ~cellfun(@isempty,obj.parameter);
            varargout(specified) = obj.parameter(specified);
        end
    end
end