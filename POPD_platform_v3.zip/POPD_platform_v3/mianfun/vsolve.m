function vsolve(vshur,outt,dmatv,mismat)

fig = uifigure;
dtt = uiprogressdlg(fig,'Title','Please Wait',...
    'Message','1','Cancelable','on');
dtt.Message = "The parameters you set are being simulated.";

global rs N NJ step  delt_T T  
global qss1 qsv1 qdd1 qdv1 qss2 qsv2 qdd2 qdv2  y t
global  meh  M KR CR  KRD CSD GR O O2   u3 u4 u5 u3S u4S u5S  ksp kspS  OC1 OC2 OC1C OC2C  kpd ks cpr pay paz aaz aay 
global fn0 fn0S fd fd2 fj fj2 qd0 qd0S ku kuS  ce ceS  kc1 kc2     
 
% assignin("base","vshur",vshur)
% assignin("base","outt",outt)
% assignin("base","dmatv",dmatv)
% assignin("base","mismat",mismat)
% assignin("base"," kpd", kpd)
% assignin("base"," ks", ks)

rs=vshur(1);N=vshur(2);NJ=N+1;step=vshur(3);damper=vshur(4);
M=outt.Mats.M; KR=outt.Mats.KR; CR=outt.Mats.CR; KRD=outt.Mats.KRD;CSD=outt.Mats.CSD; GR=outt.Mats.GR;
O=outt.Vec.O; O2=outt.Vec.O2; OC1=outt.Vec.OC1;OC2=outt.Vec.OC2; OC1C=outt.Vec.OC1C; OC2C=outt.Vec.OC2C; meh=outt.Vec.meh;
kc1=outt.kcc(1); kc2=outt.kcc(2); fd=outt.kcc(4); fd2=outt.kcc(6); fj=outt.kcc(3); fj2=outt.kcc(5);
qd0=dmatv.Var2(1);
ce=dmatv.Var2(2);
fn0=dmatv.Var2(3);
ksp=dmatv.Var2(4);
ku=dmatv.Var2(7);
u3=dmatv.Var2(12);
u4=dmatv.Var2(13);
u5=dmatv.Var2(10);
qd0S=dmatv.Var3(1);
ceS=dmatv.Var3(2);
fn0S=dmatv.Var3(3);
kspS=dmatv.Var2(4);
kuS=dmatv.Var3(7);
u3S=dmatv.Var3(12);
u4S=dmatv.Var3(13);
u5S=dmatv.Var3(10);

aaz=mismat.Var3(1); 
aay=mismat.Var3(2);
pay=mismat.Var3(3)*1e-3;
paz=mismat.Var3(4)*1e-3; 
cpr=mismat.Var3(7);

p0s=0.00001+0.00001i;
p0=[p0s;p0s;p0s;p0s;p0s;p0s;0;0;0;0;0;0;0;0;p0s;p0s;p0s;p0s;p0s;p0s;0;0;0;0;0;0;0;0;];  

dtt.Value=0.1;
T=2*pi/rs;

delt_T=T/step;
tspan=[0:delt_T:100*T];   

dtt.Value=0.2;

if damper==0
  
[t,p]=ode113('bendvfree2',tspan,p0);
p0=p(end,:);
tspan=[100*T:delt_T:200*T];  
[t,p]=ode113('bendvfree2',tspan,p0);     
    
else
[t,p]=ode113('bendvc1',tspan,p0);
p0=p(end,:);
tspan=[100*T:delt_T:200*T];  
[t,p]=ode113('bendvc1',tspan,p0);   
    
end

dtt.Value=0.8;

qss1=p(:,1:N)*O(1:N)';
qsv1=p(:,NJ+1:NJ*2-1)*O(1:N)';
qsss1=qss1;
qsvv1=qsv1;

y(:,1)=real(qsss1);
y(:,2)=imag(qsss1);
y(:,3)=real(qsvv1);
y(:,4)=imag(qsvv1);


qdd1=p(:,NJ);
qdv1=p(:,NJ*2);

qddd1=qdd1;
qdvv1=qdv1;

y(:,5)=real(qddd1);
y(:,6)=imag(qddd1);
y(:,7)=real(qdvv1);
y(:,8)=imag(qdvv1);

dtt.Value=0.85;

qss2=p(:,NJ*2+1:NJ*3-1)*O2(1:N)';
qsv2=p(:,NJ*3+1:NJ*4-1)*O2(1:N)';

qsss2=qss2;
qsvv2=qsv2;

y(:,9)=real(qsss2);
y(:,10)=imag(qsss2);
y(:,11)=real(qsvv2);
y(:,12)=imag(qsvv2);

qdd2=p(:,NJ*3);
qdv2=p(:,NJ*4);

qddd2=qdd2;
qdvv2=qdv2;


y(:,13)=real(qddd2);
y(:,14)=imag(qddd2);
y(:,15)=real(qdvv2);
y(:,16)=imag(qdvv2);

y=y/1e-3; % to millimeter

% assignin("base","y",y)
% assignin("base","delt_T",delt_T)
% assignin("base","T",T)
% assignin("base","t",t)

dtt.Value=0.9;
close(dtt);
close(fig);
end

