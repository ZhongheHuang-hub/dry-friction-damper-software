%第二-第三阶段的稳态振幅，输入多参数不用设置全局变量
function p3=amt3f(w,ths)

cs1=ths(1); cn1=ths(2); cs2=ths(3); cn2=ths(4); ccd=ths(5); e1=ths(6); e2=ths(7); ce2d=ths(8); m2=ths(9); md=ths(10);
k2=ths(11); k3d=ths(12); kd=ths(13); k2d=ths(14); g1=ths(15); g2=ths(16); ks1=ths(17); ks2=ths(18); bc=ths(19); md1=ths(20);
md2=ths(21); ku=ths(22); QD0=ths(23); dt=ths(24);u=ths(25);

c1=1-w^2-w^2*g1+1i*(2*w*(cs1+cn1)-w*ks1);
c2=k2-w^2*m2-w^2*g2+1i*(2*w*(cs2+cn2)-w*ks2);
cd1=-w*2*md+1i*(2*w*ccd);


ff3=kd*(1-ce2d/QD0);
cd=cd1+ff3;
ke2=(1+1i*u)*bc*(c2*w^2*md1*e1*cd+c1*w^2*md2*e2*cd)/(c2*c1*cd);
ke1=(1+1i*u)*bc*(c2*md1^2*cd+c1*md2^2*cd+c1*c2)/(c2*c1*cd);
r2=real(ke2);
r1=real(ke1);
xu2=imag(ke2);
xu1=imag(ke1);
k=bc*dt*(1+u^2)^(1/2);
o1=(-(1+r1)*k+(((1+r1)^2+xu1^2)*(r2^2+xu2^2)-k^2*xu1^2)^(1/2))/((1+r1)^2+xu1^2);
ot1=ke2/(1+k/o1+ke1);
pd=ot1/cd;
qd=norm(pd);
p1=(e1*w^2-ot1*md1)/c1;
p2=(e2*w^2-ot1*md2)/c2;
ph1=p1*md1+p2*md2;
qh1=norm(ph1);
th1=angle(ph1);
fc=norm(ot1);
q1=norm(p1);
q2=norm(p2);
t1=angle(p1);
t2=angle(p2); 
td=angle(pd);

p3=[qh1,qd,o1,q1,q2,qd,t1,t2,td,fc];
