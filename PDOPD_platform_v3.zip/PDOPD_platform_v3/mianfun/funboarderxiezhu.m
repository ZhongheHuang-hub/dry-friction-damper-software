function fcs=funboarderxiezhu(c)

tt1=evalin('base','tt1');
fcs=tt1*c;

end