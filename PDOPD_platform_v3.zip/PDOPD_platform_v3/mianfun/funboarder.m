function f=funboarder(p)
%cLear
syms c1 c2 c3 c4 x xy 
global E I kpd ks L1 shadtnum LS ES IS

af=c1*cos(p*x)+c2*sin(p*x)+c3*cosh(p*x)+c4*sinh(p*x);
afd1=vpa(diff(af,x,1));
afd2=vpa(diff(af,x,2));
afd3=vpa(diff(af,x,3));

if shadtnum==1

%% spring
q1=E*I*afd3-kpd(1)*af;  %平移刚度
q2=E*I*afd2+ks(1)*afd1; %角刚度

q1l=E*I*afd3-kpd(2)*af;  %平移刚度
q2l=E*I*afd2+ks(2)*afd1; %角刚度

qtt(1)=vpa(subs(q1,x,0));
qtt(2)=vpa(subs(q2,x,0));
qtt(3)=vpa(subs(q1l,x,L1));
qtt(4)=vpa(subs(q2l,x,L1));

else %shaft2 
q1=ES*IS*afd3-kpd(2)*af;  %平移刚度
q2=ES*IS*afd2+ks(2)*afd1; %角刚度

q1l=ES*IS*afd3-kpd(3)*af;  %平移刚度
q2l=ES*IS*afd2+ks(3)*afd1; %角刚度

qtt(1)=vpa(subs(q1,x,0));
qtt(2)=vpa(subs(q2,x,0));
qtt(3)=vpa(subs(q1l,x,LS));
qtt(4)=vpa(subs(q2l,x,LS));
end

tt=zeros(4,4);
for i=1:4
    for j=1:4
        zj=coeffs(qtt(i),eval(['c',num2str(j)]));
        if length(zj)==2
        tt(i,j)=zj(2);
        else
        tt(i,j)=0;
        end
    end
end

assignin('base','tt1',tt);
f=det(tt);

