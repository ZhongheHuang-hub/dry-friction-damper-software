function out= Rpmfun(tsww,mismat,dmat,damper,N) % calculate the rpm and other

global  radi L1 E kpd ks LS ES cpr shadtnum I IS
cc=0.0001;
g=9.8;
L3=76e-3; %same of double shaft


%% shaft 1
cn1=728;
kn1=1.5e5;

den=tsww.Var2(1);
E=tsww.Var2(2);
rad=tsww.Var2(3);
L1=tsww.Var2(4);
radi=tsww.Var2(5);
wi=tsww.Var2(6);
d2=tsww.Var2(7);
thick=tsww.Var2(8);
Ler=tsww.Var2(9);

%% couping
Lcp=4e-2;%  the lenth of bolt of the coupling to connect the melt and halp coupling
Lc1=L1+Lcp; % here the force is in the mid of the couping 
Lc2=-Lcp; % the start of the second shaft is form the left end of shaft
for j=1:3
kpd(j)=mismat.(['Var', num2str(j+1)])(5)*1e3;
ks(j)=mismat.(['Var', num2str(j+1)])(6)*1e-3;
end
% assignin("base","kpd", kpd)
% assignin("base","ks", ks)

%%
A=pi*(rad^2-(rad-thick)^2);
I=pi*(rad*2)^4/64*(1-((rad-thick)/rad)^4);
syms x r ;
%inner sleeve radius 1
rado1=0.138/2;
wo1=50e-3;
tko1=rado1-rad;
Ios1=pi*(rado1*2)^4/64*(1-((rado1-tko1)/rado1)^4)*wo1;

%inner sleeve radius 2
rado2=0.145/2;
wo2=8e-3;
tko2=rado2-rado1;
Ios2=pi*(rado2*2)^4/64*(1-((rado2-tko2)/rado2)^4)*wo2;
deno=2850;
Io=(Ios1+Ios2)*deno;
tki=radi-rado1;
Iis=pi*(radi*2)^4/64*(1-((radi-tki)/radi)^4)*wi;
deni=7850;
Ii=Iis*deni;
mout=pi*wo1*(rado1^2-(rado1-tko1)^2)*deno+pi*wo2*(rado2^2-(rado2-tko2)^2)*deno+pi*wi*(radi^2-(radi-tki)^2)*deni;


shadtnum=1;
for i=1:N 
pp(i)=fsolve(@funboarder,[0.9*i+0.3]); % solve the p in modal function
ck(:,i)=fsolve(@funboarderxiezhu,[1;1;1;1]);
end
modelfun=sym(zeros(N,1));
realmfun=sym(zeros(N,1));
for i=1:N 
modelfun(i)=[cos(pp(i)*x),sin(pp(i)*x),cosh(pp(i)*x),sinh(pp(i)*x)]*ck(:,i);
aa(i)=double((1/(den*A*int(modelfun(i).^2,x,0,L1)))^(1/2));
realmfun(i)=modelfun(i)*aa(i);
end

for i=1:N 
V(i)=realmfun(i);
VD1(i)=diff(realmfun(i),x,1);%%1阶微分 speed
VD2(i)=diff(realmfun(i),x,2);%%2阶微分
VD4(i)=diff(realmfun(i),x,4);%%4阶微分
V2(i)=realmfun(i).*realmfun(i);

mr(i)=den*A*int(V2(i),x,0,L1)-den*I*int(V(i).*VD2(i),x,0,L1)+mout*subs(V(i),x,d2)-(Ii+Io)*subs(VD2(i),x,d2);%质量
kr(i)=E*I*int(V(i)*VD4(i),x,0,L1)+kn1*subs(V(i),x,L3);
gr(i)=2*den*I*int(V(i)*VD2(i),x,0,L1)+2*(Ii+Io)*subs(VD2(i),x,d2);%陀螺 这里面没有 角速度 
cr(i)=cn1*subs(V(i),x,L3);

fgr(i)=g*den*A*int(V(i),x,0,L1);%%重力
me(i)=den*A*int(V2(i),x,0,L1)*Ler;
krd(i)=cc*kr(i);%旋转结构附加弹性力
csd(i)=cc*kr(i);%旋转结构阻尼
O(i)=double(subs(V(i),x,d2));
%couping
OC1(i)=double(subs(V(i),x,Lc1)); % 
OC1C(i)=double(subs(VD1(i),x,Lc1)); %speed
end

%% shaft 2

cn2=728;
kn2=0.5e5;

denS=tsww.Var3(1);
ES=tsww.Var3(2);
radS=tsww.Var3(3);
LS=tsww.Var3(4);
radiS=tsww.Var3(5);
wiS=tsww.Var3(6);
d2S=tsww.Var3(7);
thickS=tsww.Var3(8);
LerS=tsww.Var3(9);

AS=pi*(radS^2-(radS-thickS)^2);
IS=pi*(radS*2)^4/64*(1-((radS-thickS)/radS)^4);

%内套半径1
rado1S=0.138/2;
wo1S=50e-3;
tko1S=rado1S-radS;
Ios1S=pi*(rado1S*2)^4/64*(1-((rado1S-tko1S)/rado1S)^4)*wo1S;

%内套半径2
rado2S=0.145/2;
wo2S=8e-3;
tko2S=rado2S-rado1S;
Ios2S=pi*(rado2S*2)^4/64*(1-((rado2S-tko2S)/rado2S)^4)*wo2S;
denoS=2850;
IoS=(Ios1S+Ios2S)*denoS;
tkiS=radiS-rado1S;
IisS=pi*(radiS*2)^4/64*(1-((radiS-tkiS)/radiS)^4)*wiS;
deniS=7850;
IiS=IisS*deniS;
moutS=pi*wo1S*(rado1S^2-(rado1S-tko1S)^2)*denoS+pi*wo2S*(rado2S^2-(rado2S-tko2S)^2)*denoS+pi*wiS*(radiS^2-(radiS-tkiS)^2)*deniS;

shadtnum=2;
for i=1:N 
pp(i)=fsolve(@funboarder,[0.9*i+0.3]); % solve the p in modal function
ck(:,i)=fsolve(@funboarderxiezhu,[1;1;1;1]);
end
modelfun=sym(zeros(N,1));
realmfun=sym(zeros(N,1));
for i=1:N 
modelfun(i)=[cos(pp(i)*x),sin(pp(i)*x),cosh(pp(i)*x),sinh(pp(i)*x)]*ck(:,i);
aa(i)=double((1/(denS*AS*int(modelfun(i).^2,x,0,LS)))^(1/2));
realmfun(i)=modelfun(i)*aa(i);
end

for i=1:N 
VS(i)=realmfun(i);
VD1S(i)=diff(realmfun(i),x,1);%%1 
VD2S(i)=diff(realmfun(i),x,2);%%2
VD4S(i)=diff(realmfun(i),x,4);%%4
V2S(i)=realmfun(i).*realmfun(i);

mr2(i)=denS*AS*int(V2S(i),x,0,LS)-denS*IS*int(VS(i).*VD2S(i),x,0,LS)+moutS*subs(VS(i),x,d2S)-(Ii+Io)*subs(VD2S(i),x,d2S);%质量
kr2(i)=ES*IS*int(VS(i)*VD4S(i),x,0,LS)+kn2*subs(VS(i),x,L3);
gr2(i)=2*denS*IS*int(VS(i)*VD2S(i),x,0,LS)+2*(IiS+IoS)*subs(VD2S(i),x,d2S);%陀螺 这里面没有 角速度 
cr2(i)=cn2*subs(V(i),x,L3);
fgr2(i)=g*denS*AS*int(VS(i),x,0,LS);%%重力
me2(i)=denS*AS*int(V2S(i),x,0,LS)*LerS;
krd2(i)=cc*kr2(i);%旋转结构附加弹性力
csd2(i)=cc*kr2(i);%旋转结构阻尼
O2(i)=double(subs(VS(i),x,d2S));
%couping
OC2(i)=double(subs(VS(i),x,Lc2)); % 
OC2C(i)=double(subs(VD1S(i),x,Lc2)); %speed
end

lj1=sqrt(double(kr(1)/mr(1)));
lj1rpm=lj1/(2*pi)*60;
lj12=sqrt(double(kr2(1)/mr2(1)));
lj1rpm2=lj12/(2*pi)*60;
for i=1:N
lj(i)=double(sqrt(double(kr(i)/mr(i))));
ljsecond(i)=double(sqrt(double(kr2(i)/mr2(i))));
end
%%
NJ=N+1;

mh=zeros(2*NJ,1);kh=zeros(2*NJ,1);gh=zeros(2*NJ,1);ch=zeros(2*NJ,1);meh=zeros(2*NJ,1);
fh=zeros(2*NJ,1);krdh=zeros(2*NJ,1);csdh=zeros(2*NJ,1);

mh(1:N)=mr(1:N);mh(NJ+1:2*NJ-1)=mr2(1:N);
kh(1:N)=kr(1:N);kh(NJ+1:2*NJ-1)=kr2(1:N);
ch(1:N)=cr(1:N);ch(NJ+1:2*NJ-1)=cr2(1:N);
meh(1:N)=me(1:N);meh(NJ+1:2*NJ-1)=me2(1:N);
krdh(1:N)=krd(1:N);krdh(NJ+1:2*NJ-1)=krd2(1:N);
csdh(1:N)=csd(1:N);csdh(NJ+1:2*NJ-1)=csd2(1:N);
gh(1:N)=gr(1:N);gh(NJ+1:2*NJ-1)=gr2(1:N);


M=diag(mh);
KR=diag(kh);
CR=diag(ch);
KRD=diag(krdh);
CSD=diag(csdh);
GR=diag(gh);
%% damper

O(NJ)=-1;
% OR(NJ)=-1;
O2(NJ)=-1;
ce=dmat.Var2(2);
fn0=dmat.Var2(3);
md=dmat.Var2(5);
Ed=dmat.Var2(6);
u1=dmat.Var2(8);
u2=dmat.Var2(9);
cd=dmat.Var2(11);

ceS=dmat.Var3(2);
fn0S=dmat.Var3(3);
mdS=dmat.Var3(5);
EdS=dmat.Var3(6);
u1S=dmat.Var3(8);
u2S=dmat.Var3(9);
cdS=dmat.Var3(11);

%first
M(NJ,NJ)=md;
CR(NJ,NJ)=cd;

%second
M(2*NJ,2*NJ)=mdS;
CR(2*NJ,2*NJ)=cdS;

fj=2*(u1+u2)*fn0;
fd=fj*0.8;

fj2=2*(u1S+u2S)*fn0S;
fd2=fj2*0.8;


%% connect stiffness
if damper==1
    % fea result
    kc1=0.917e5*1.91;
else
    kc1=0.806e5*2.148;
end

ud=0.4;
Es=1.7e11;% e of outer sleeve
us=0.3;
dd=radi+ce;% connect radies

arf=0.8*(9/16*((1-ud^2)/Ed+(1-us^2)/Es)^2*(1/radi+1/dd))^(1/3);
T0=1/2*mr(1)*0.334^2;
kc2=(1.0948*(md/(md+mr(1))*T0/arf^6))^(1/5); 

Mat=struct('M',M,'KR',KR,'CR',CR,'KRD',KRD,'CSD',CSD,'GR',GR); % maxtrix
Vec=struct('O',O,'O2',O2,'OC1',OC1,'OC2',OC2,'OC1C',OC1C,'OC2C',OC2C,'meh',meh,'lj',lj,'ljsecond',ljsecond,'V',V,'VS',VS); %vector
out=struct('Mats',Mat,'Vec',Vec,'kcc',double([kc1,kc2,fj,fd,fj2,fd2,lj1,lj1rpm,lj12,lj1rpm2])); %


end