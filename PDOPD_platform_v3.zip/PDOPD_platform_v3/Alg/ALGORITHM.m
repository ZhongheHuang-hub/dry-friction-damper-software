classdef ALGORITHM < handle & matlab.mixin.Heterogeneous
    properties(SetAccess = private)
        parameter = {};                 % parameters of the algorithm
        save      = 0;                  % number of populations saved in an execution
        outputFcn = @ALGORITHM.Output;	% function called after each generation
        pro;                            % problem solved in current execution
        result;                         % populations saved in current execution
        metric;                         % metric values of current populations
        myapp;                          % opt1
        stopp                           %stopfigure
    end
    methods(Access = protected) %
        function obj = ALGORITHM(varargin)
            
            isStr = find(cellfun(@ischar,varargin(1:end-1))&~cellfun(@isempty,varargin(2:end)));
            for i = isStr(ismember(varargin(isStr),{'parameter','save','outputFcn','myapp','stopp'})) %for the three properties
                obj.(varargin{i}) = varargin{i+1};
            end
        end
    end
    methods(Sealed)
        function Solve(obj,Problem)
            obj.pro    = Problem;
            obj.result = {};
            obj.metric = struct('runtime',0);
            obj.pro.FE = 0;
            
            addpath(fileparts(which(class(obj))));
            addpath(fileparts(which(class(obj.pro))));
            tic; obj.main(PROBLEM.Current(obj.pro));
        end
    end
    methods
        function main(obj,Problem)
        end
    end
    methods(Access = protected, Sealed)
        function nofinish = NotTerminated(obj,Population) %循环
            obj.metric.runtime = obj.metric.runtime + toc; %记录时间
            if obj.save <= 0; num = 10; else; num = obj.save; end
            index = max(1,min(min(num,size(obj.result,1)+1),ceil(num*obj.pro.FE/obj.pro.maxFE)));
            obj.result(index,:) = {obj.pro.FE,Population};
            drawnow();
            obj.outputFcn(obj,obj.pro);
            nofinish = obj.pro.FE < obj.pro.maxFE;
            if  obj.stopp==1
                nofinish=0;
            end
%             assignin('base','stt',obj.stopp)
        end
        function varargout = ParameterSet(obj,varargin)
            varargout = varargin;
            specified = ~cellfun(@isempty,obj.parameter);
            varargout(specified) = obj.parameter(specified);
        end
    end
    
    methods(Static, Sealed)
        function Output(Algorithm,Problem) %plot figure
            fprintf('%s on %d-objective %d-variable %s (%6.2f%%), %.2fs passed...\n',class(Algorithm),Problem.M,Problem.D,class(Problem),Problem.FE/Problem.maxFE*100,Algorithm.metric.runtime);
            Algorithm.myapp.time.Value=Algorithm.metric.runtime;
            procesd=Problem.FE/Problem.maxFE*100;
            if procesd<=100.01
                Algorithm.myapp.GenSlider.Value=procesd;
                Algorithm.myapp.EditField.Value=procesd;
            end
            
            Population = Algorithm.result{end};
            for i=1:length(Population)
                for j=1:length(Population(1,1).obj)
                    kkk(j,i)=Population(1,i).obj(j);
                end
            end
            
            kkk=kkk';
            btt=Algorithm.myapp.ObjectivesListBox.Value;
%             assignin('base','btt',btt);

            if length(Population(1,1).obj)==3
                plot3(Algorithm.myapp.UIAxes,kkk(:,1),kkk(:,2),kkk(:,3),'o','MarkerSize', 5);
                Algorithm.myapp.UIAxes.XLabel.String=['f1',btt{1}];Algorithm.myapp.UIAxes.YLabel.String=['f2',btt{2}];Algorithm.myapp.UIAxes.ZLabel.String=['f3',btt{3}];
%                 grid(Algorithm.myapp.UIAxes,'on')
%                 Algorithm.myapp.UIAxes.GridColor = 'b';
            elseif length(Population(1,1).obj)<3
                plot(Algorithm.myapp.UIAxes,kkk(:,1),kkk(:,2),'o','MarkerSize', 5);
                Algorithm.myap.UIAxes.XLabel.String=['f1',btt{1}];Algorithm.myapp.UIAxes.XLabel.String=['f2',btt{2}];
%                 grid(Algorithm.myapp.UIAxes,'on')
%                 Algorithm.myapp.UIAxes.GridColor = 'b';
                Algorithm.myapp.UIAxes.XColor = 'b';  Algorithm.myapp.UIAxes.YColor = 'b';  Algorithm.myapp.UIAxes.ZColor = 'b';
            elseif length(Population(1,1).obj)>3
                Label = repmat([0.99,2:size(kkk,2)-1,size(kkk,2)+0.01],size(kkk,1),1);
                kkk(2:2:end,:)  = fliplr(kkk(2:2:end,:));
                Label(2:2:end,:) = fliplr(Label(2:2:end,:));
                plot(Algorithm.myapp.UIAxes,reshape(Label',[],1),reshape(kkk',[],1))
            end
            
            if Problem.FE >= Problem.maxFE
                if Algorithm.save > 0
                    folder = fullfile('Datasave',class(Algorithm));
                    [~,~]  = mkdir(folder);
                    file   = fullfile(folder,sprintf('%s_%s_M%d_D%d_',class(Algorithm),class(Problem),Problem.M,Problem.D));
                    runNo  = 1;
                    while exist([file,num2str(runNo),'.mat'],'file') == 2
                        runNo = runNo + 1;
                    end
                    result = Algorithm.result;
                    metric = Algorithm.metric;
                    save([file,num2str(runNo),'.mat'],'result','metric');
                end
            end
        end
        
        function cb_menu(h)
            % Switch the selected menu.
            set(get(get(h,'Parent'),'Children'),'Checked','off');
            set(h,'Checked','on');
        end
    end
    methods(Sealed)
        function value = Metric(obj,name,nPoints)
            % Calculate metric values.
            if nargin < 3
                index = 1 : size(obj.result,1);
            else
                index = ceil(linspace(1,size(obj.result,1),nPoints));
            end
            name = strrep(name,' ','');
            if ~isfield(obj.metric,name)
                obj.metric.(name) = [cell2mat(obj.result(index,1)),cellfun(@(S)feval(name,S,obj.pro.optimum),obj.result(index,2))];
            end
            value = obj.metric.(name);
        end
    end
end

function score = Minimumvalue(Population,~)
score = Population.best.objs;
if isempty(score); score = nan; end
end

function score = Feasiblerate(Population,~)
score = mean(all(Population.cons<=0,2));
end