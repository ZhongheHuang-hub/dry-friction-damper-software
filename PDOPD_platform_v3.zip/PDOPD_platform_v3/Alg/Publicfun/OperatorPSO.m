function Offspring = OperatorPSO(Particle,Pbest,Gbest,W)
%OperatorPSO - The operator of particle swarm optimization.


    %% Parameter setting
    if nargin < 4
        W = 0.4;
    end
    ParticleDec = Particle.decs;
    PbestDec    = Pbest.decs;
    GbestDec    = Gbest.decs;
    [N,D]       = size(ParticleDec);
    ParticleVel = Particle.adds(zeros(N,D));

    %% Particle swarm optimization
    r1        = repmat(rand(N,1),1,D);
    r2        = repmat(rand(N,1),1,D);
    OffVel    = W.*ParticleVel + r1.*(PbestDec-ParticleDec) + r2.*(GbestDec-ParticleDec);
    OffDec    = ParticleDec + OffVel;
    Offspring = SOLUTION(OffDec,OffVel);
end