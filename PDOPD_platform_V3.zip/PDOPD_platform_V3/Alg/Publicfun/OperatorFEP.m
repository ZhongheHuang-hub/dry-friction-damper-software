function Offspring = OperatorFEP(Population)


    %% Parameter setting
    PopulationDec = Population.decs;
    [N,D]         = size(PopulationDec);
    PopulationEta = Population.adds(rand(N,D));
    
    %% Fast evolutionary programming
    tau  = 1/sqrt(2*sqrt(D));
    tau1 = 1/sqrt(2*D);
    GaussianRand  = repmat(randn(N,1),1,D);
    GaussianRandj = randn(N,D);
    CauchyRandj   = trnd(1,N,D);
    OffDec        = PopulationDec + PopulationEta.*CauchyRandj;
    OffEta        = PopulationEta.*exp(tau1*GaussianRand+tau*GaussianRandj);
    Offspring     = SOLUTION(OffDec,OffEta);
end