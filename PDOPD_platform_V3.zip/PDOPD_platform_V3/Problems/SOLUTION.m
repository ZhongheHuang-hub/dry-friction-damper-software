classdef SOLUTION < handle
%SOLUTION - The class of a solution.

%
% SOLUTION properties:
%   dec         <read-only>     decision variables of the solution
%   obj         <read-only>     objective values of the solution
%   con         <read-only>     constraint violations of the solution
%   add         <read-only>     additional properties of the solution
%
% SOLUTION methods:
%   SOLUTION	<public>        the constructor, which sets all the
%                               properties of the solution
%   decs        <public>      	get the matrix of decision variables of
%                               multiple solutions
%   objs        <public>        get the matrix of objective values of
%                               multiple solutions
%   cons        <public>        get the matrix of constraint violations of
%                               multiple solutions
%   adds        <public>        get the matrix of additional properties of
%                               multiple solutions
%   best        <public>        get the feasible and nondominated solutions
%                               among multiple solutions



    properties(SetAccess = private)
        dec;        % Decision variables of the solution
        obj;        % Objective values of the solution
        con;        % Constraint violations of the solution
        add;        % Additional properties of the solution
    end
    methods
        function obj = SOLUTION(PopDec,AddPro)

        
            if nargin > 0
                obj(1,size(PopDec,1)) = SOLUTION;
                Problem = PROBLEM.Current();
                PopDec  = Problem.CalDec(PopDec);
                PopObj  = Problem.CalObj(PopDec);
                PopCon  = Problem.CalCon(PopDec);
                for i = 1 : length(obj)
                    obj(i).dec = PopDec(i,:);
                    obj(i).obj = PopObj(i,:);
                    obj(i).con = PopCon(i,:);
                end
                if nargin > 1
                    for i = 1 : length(obj)
                        obj(i).add = AddPro(i,:);
                    end
                end
                Problem.FE = Problem.FE + length(obj);
            end
        end
        function value = decs(obj)

        
            value = cat(1,obj.dec);
        end
        function value = objs(obj)

        
            value = cat(1,obj.obj);
        end
        function value = cons(obj)

        
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddPro)


            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddPro(i,:);
                end
            end
            value = cat(1,obj.add);
        end
        function P = best(obj)

        
            Feasible = find(all(obj.cons<=0,2));
            if isempty(Feasible)
                Best = [];
            elseif length(obj(1).obj) > 1
                Best = NDSort(obj(Feasible).objs,1) == 1;
            else
                [~,Best] = min(obj(Feasible).objs);
            end
            P = obj(Feasible(Best));
        end
    end
end