function vsolvec(vshur,outt,dmat,mismat)
fjs = uifigure;
dj = uiprogressdlg(fjs,'Title','Please Wait',...
    'Message','1','Cancelable','on');
dj.Message = "The parameters you set are being simulated.";
%��ת���µ�����

global st en step N NJ range  O2 cah biyf cahs f  delt_T T rs
global amf amdf ams amds sq1 sq2 sqd1 sqd2 bif bi1f bi2f bify bidf bid2f bis bi1s bi2s biys bids bid1s bid2s bid1f amfz amdfz amsz amdsz
global C1 C2 C3 C4 DD1 DD2 DD3 DD4 DD5 DD6 DD7 DD8
global qss1 qsv1 qdd1 qdv1 qss2 qsv2 qdd2 qdv2  t 
global  meh  M KR CR  KRD CSD GR O  u3 u4 u5 u3S u4S u5S  ksp kspS   OC1 OC2 OC1C OC2C cpr pay paz aaz aay 
global fn0 fn0S fd fd2 fj fj2 qd0 qd0S ku kuS  ce ceS  kc1 kc2     
global mffc1 affc1 mffc2 affc2

% assignin("base","vshur",vshur)
% assignin("base","outt",outt)
% assignin("base","dmat",dmat)
% assignin("base","d2mat",d2mat)
% assignin("base","mismat",mismat)

N=vshur(2);NJ=N+1;step=vshur(3);damper=vshur(4); st=vshur(5);en=vshur(6);
M=outt.Mats.M; KR=outt.Mats.KR; CR=outt.Mats.CR; KRD=outt.Mats.KRD;CSD=outt.Mats.CSD; GR=outt.Mats.GR;
O=outt.Vec.O; O2=outt.Vec.O2; OC1=outt.Vec.OC1;OC2=outt.Vec.OC2; OC1C=outt.Vec.OC1C; OC2C=outt.Vec.OC2C; meh=outt.Vec.meh;

kc1=outt.kcc(1); kc2=outt.kcc(2); fd=outt.kcc(4); fd2=outt.kcc(6); fj=outt.kcc(3); fj2=outt.kcc(5);
qd0=dmat.Var2(1);
ce=dmat.Var2(2);
fn0=dmat.Var2(3);
ksp=dmat.Var2(4);
ku=dmat.Var2(7);
u3=dmat.Var2(12);
u4=dmat.Var2(13);
u5=dmat.Var2(10);

qd0S=dmat.Var3(1);
ceS=dmat.Var3(2);
fn0S=dmat.Var3(3);
kspS=dmat.Var2(4);
kuS=dmat.Var3(7);
u3S=dmat.Var3(12);
u4S=dmat.Var3(13);
u5S=dmat.Var3(10);

aaz=mismat.Var3(1); 
aay=mismat.Var3(2);
pay=mismat.Var3(3)*1e-3;
paz=mismat.Var3(4)*1e-3; 
cpr=mismat.Var3(7);

range=[st:2:en];%ת�ٱ仯 ���ܴ�0��ʼ
k=1;

amf=[];%���
amfz=[];
bif=[];%�ֲ���¼1
bi1f=[];%�ֲ���¼2
bi2f=[];%�ֲ���¼3 
bify=[];%�ֲ���¼2

amdf=[];
amdfz=[];

bidf=[];
bid1f=[];
bid2f=[];

ams=[];%���
amsz=[];
bis=[];%�ֲ���¼1
bi1s=[];%�ֲ���¼2
bi2s=[];%�ֲ���¼3 
biys=[];%�ֲ���¼2

amds=[];
amdsz=[];
bids=[];
bid1s=[];
bid2s=[];


sq1=[];
sq2=[];
sqd1=[];
sqd2=[];
DD1=[]; DD2=[]; DD3=[]; DD4=[]; DD5=[]; DD6=[]; DD7=[]; C1=[]; C2=[]; C3=[]; C4=[]; cah=[]; cahs=[]; mffc1=[];affc1=[];mffc2=[];affc2=[];
NT=3000;
n=0:NT-1;

p0s=0.00001+0.00001i;
p0=[p0s;p0s;p0s;p0s;p0s;p0s;0;0;0;0;0;0;0;0;p0s;p0s;p0s;p0s;p0s;p0s;0;0;0;0;0;0;0;0;];  
dj.Value=0.1;

for rs=range
rs

T=2*pi/rs;
delt_T=T/step;
fs=1/delt_T;%
time=n/fs;%
f=(n*fs/NT)*T;

tspan=[0:delt_T:100*T];   
if damper==0
    
[t,p]=ode113('bendvfree2',tspan,p0);
p0=p(end,:);
tspan=[100*T:delt_T:200*T];  
[t,p]=ode113('bendvfree2',tspan,p0);     
    
else
[t,p]=ode113('bendvc1',tspan,p0);
p0=p(end,:);
tspan=[100*T:delt_T:200*T];  
[t,p]=ode113('bendvc1',tspan,p0);   
    
end
dj.Value=0.2;

qss1=p(:,1:N)*O(1:N)';
qsv1=p(:,NJ+1:NJ*2-1)*O(1:N)';
qdd1=p(:,NJ);
qdv1=p(:,NJ*2);
qss2=p(:,NJ*2+1:NJ*3-1)*O2(1:N)';
qsv2=p(:,NJ*3+1:NJ*4-1)*O2(1:N)';
qdd2=p(:,NJ*3);
qdv2=p(:,NJ*4);


qss1=qss1-mean(qss1);
qsv1=qsv1-mean(qsv1);
qdd1=qdd1-mean(qdd1);
qdv1=qdv1-mean(qdv1);
qss2=qss2-mean(qss2);
qsv2=qsv2-mean(qsv2);
qdd2=qdd2-mean(qdd2);
qdv2=qdv2-mean(qdv2);


sq1=abs(fft(real(qss1),NT))*2/NT;
sq2=abs(fft(real(qss2),NT))*2/NT;
sqd1=abs(fft(real(qdd1),NT))*2/NT;
sqd2=abs(fft(real(qdd2),NT))*2/NT;


dj.Value=0.4;
amf(k,1)=max(abs(qss1));
amdf(k,1)=max(abs(qdd1));

amfz(k,1)=abs(max(real(qss1)));
amdfz(k,1)=abs(max(real(qdd1)));

bif(k,:)=real(qss1(1:100:end,1));  
biyf(k,:)=imag(qss1(1:100:end,1));   
bi1f(k,:)=real(qss1(10:100:end,1));
bi2f(k,:)=real(qss1(20:100:end,1));
bidf(k,:)=real(qdd1(1:100:end,1)); 
bid1f(k,:)=real(qdd1(10:100:end,1)); 
bid2f(k,:)=real(qdd1(20:100:end,1)); 

ams(k,1)=max(abs(qss2));
amds(k,1)=max(abs(qdd2));

amsz(k,1)=abs(max(real(qss2)));
amdsz(k,1)=abs(max(real(qdd2)));

bis(k,:)=real(qss2(51:100:end,1));  
biys(k,:)=imag(qss2(51:100:end,1));   
bi1s(k,:)=real(qss2(60:100:end,1));
bi2s(k,:)=real(qss2(70:100:end,1));
bids(k,:)=real(qdd2(51:100:end,1)); 
bid1s(k,:)=real(qdd2(60:100:end,1)); 
bid2s(k,:)=real(qdd2(70:100:end,1)); 

C1(:,k)=sq1/1E-3;
C2(:,k)=sq2/1E-3;
C3(:,k)=sqd1/1E-3;
C4(:,k)=sqd2/1E-3;

DD1(:,k)=qss1/1E-3;%��1λ��
DD2(:,k)=qsv1/1E-3;
DD3(:,k)=qdd1/1E-3;%������1λ��
DD4(:,k)=qdv1/1E-3;
DD5(:,k)=qss2/1E-3;%��2λ��
DD6(:,k)=qsv2/1E-3;
DD7(:,k)=qdd2/1E-3;%������2λ��
DD8(:,k)=qdv2/1E-3;

for ijk=1:101 %mabbe
        ffc1(ijk,:)=fc(qss1(ijk),qdd1(ijk));
        ffc2(ijk,:)=fc(qss2(ijk),qdd2(ijk));
end

mffc1(:,k)=mean(ffc1(:,1));
affc1(:,k)=max(ffc1(:,1));
mffc2(:,k)=mean(ffc2(:,1));
affc2(:,k)=max(ffc2(:,1));

dj.Value=0.7;
cah(k,:)=(asin(sin(rs*t(1)))-atan(biyf(k,:)./bif(k,:)))/pi*180;%��10�����ݵ���λ��
cahs(k,:)=(asin(sin(rs*t(1)))-atan(biys(k,:)./bis(k,:)))/pi*180;%��10�����ݵ���λ��
if cah(k,:)<0
    cah(k,:)=cah(k,:)+180;
end 
if cahs(k,:)<0
    cahs(k,:)=cahs(k,:)+180;
end 
k=k+1;
end
dj.Value=1;
close(dj);
close(fjs);
% assignin("base","dd1zhi",DD1)
% assignin("base","rangezhi",range)
% assignin("base","amfzhi",amf)
% assignin("base","qss1zhi",qss1)
% assignin("base","mffc1zhi",mffc1)

end

